import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrls: ['./vizsgafeladat.component.css']
})
export class VizsgafeladatComponent {

  tomegErtek:number=1;
  magassagErtek:number=1;

  EredmenyMentes():void{

    this.kiirandoAdatok.push(`A ${this.tomegErtek} kg testsúlyú és ${this.magassagErtek} magasságú ember testtömeg indexe: ${this.tomegErtek/(this.magassagErtek*this.magassagErtek)}`)
  }


  kiirandoAdatok:string[]=[];

}
