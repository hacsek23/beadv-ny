/*1. feladat 
Készíts egy függvényt, ami egy paraméterként megkapott szövegben megmondja mennyi az ékezetes 
betűk mennyisége. 
Ékezetes betűk a magyarban: á, é, í, ó, ö, ő, ú, ü, ű (Illetve nagybetűs változataik) 
Függvény neve: EkezetesBetukSzama () Paraméter(ek): vizsgaltSzoveg (szöveg típusú) Visszatérési értéke: szám típusú érték*/

function EkezetesBetukSzama(vizsgaltSzoveg: string[]): number {
    
    var betukSzama: number=0;
    for (var i: number = 0; i < vizsgaltSzoveg.length; i++)
    {var ekezetesBetuk: string[] = ["á", "é", "í", "ó", "ö", "ő", "ú", "ü", "ű", "Á", "É", "Í", "Ó", "Ö", "Ő", "Ú", "Ü", "Ű"];
        for (var j: number = 0; j < ekezetesBetuk.length; j++)
       {if(vizsgaltSzoveg[i]==ekezetesBetuk[j])
        {betukSzama++;}   
        
    }
}
return betukSzama;
}


/*2. feladat 
Készítsen egy függvényt, ami a paraméterként kapott értékig megmondja mennyi az addig lévő 
számok szorzata (lásd: faktoriális fogalma). 
        Függvény neve: ElsoNszamSzorzat         Paraméterek: mennyiseg (szám típusú)         Visszatérési értéke: szám típusú változó */

function ElsoNszamSzorzat(mennyiseg:number):number 
{
    var szorzat:number=1;

    for(var i:number=1; i<=mennyiseg; i++)
    {szorzat*=i;}

    return szorzat;
}


/*3. feladat 
Készíts egy függvényt, ami egy paraméterként megkapott tömbről megmondja, mennyi a benne lévő 
páros számok összege. 
Függvény neve: ParosakOsszege() Paraméter(ek): vizsgaltTomb(számokat tartalmazó tömb) Visszatérési értéke: szám érték*/

function ParosakOsszege(vizsgaltTomb:number[]):number
{
var parosSzamokOssz:number=0;
for(var i:number=0; i<vizsgaltTomb.length; i++)
{if(vizsgaltTomb[i]%2==0)
{parosSzamokOssz+=vizsgaltTomb[i];}}

return parosSzamokOssz;

}

