function JelszoEllenor()
{
let megfelelE=true;
if(jelszo==jelszoismet)
{megfelelE==false;}
document.write(alert("A jelszó helytelen!"));
}

