var eredmenyek: string[] = [
  "1 1 atletika kalapacsvetes",
  "1 1 uszas 400m_gyorsuszas",
  "1 1 birkozas kotott_fogas_legsuly",
  "1 1 torna talajtorna",
  "1 1 torna felemas_korlat",
  "1 1 vivas kardvivas_egyeni",
  "1 1 okolvivas nagyvaltosuly",
  "1 1 uszas 200m_melluszas",
  "1 1 birkozas kotott_fogas_valtosuly",
  "1 1 uszas 100m_gyorsuszas",
  "1 1 sportloveszet onmukodo_sportpisztoly",
  "1 15 labdarugas ferfi_csapat",
  "1 3 ottusa ferfi_csapat",
  "1 6 vivas kardvivas_csapat",
  "1 5 uszas 4x100m_gyorsuszo_valto",
  "1 13 vizilabda ferfi_csapat",
  "2 1 ottusa ottusa_egyeni",
  "2 1 vivas torvivas_egyeni",
  "2 1 vivas kardvivas_egyeni",
  "2 1 sportloveszet onmukodo_sportpisztoly",
  "2 1 uszas 400m_gyorsuszas",
  "2 1 uszas 200m_melluszas",
  "2 1 kajakkenu kenu_egyes_10000m",
  "2 1 kajakkenu kajak_egyes_1000m",
  "2 1 birkozas kotott_fogas_pehelysuly",
  "2 8 torna noi_osszetett_csapat",
  "3 1 sportloveszet sportpisztoly",
  "3 1 vivas kardvivas_egyeni",
  "3 1 atletika tavolugras",
  "3 1 birkozas szabad_fogas_kozepsuly",
  "3 1 torna felemas_korlat",
  "3 1 torna osszetett_egyeni",
  "3 1 torna gerenda",
  "3 1 torna talajtorna",
  "3 1 atletika kalapacsvetes",
  "3 1 atletika 50km_gyaloglas",
  "3 1 ottusa ottusa_egyeni",
  "3 1 uszas 100m_gyorsuszas",
  "3 4 atletika 4x100m_valtofutas",
  "3 2 kajakkenu kenu_kettes_10000m",
  "3 8 torna keziszer_csapat",
  "3 6 vivas torvivas_csapat",
  "4 1 torna gerenda",
  "4 1 uszas 200m_mell",
  "4 1 birkozas kotottfogas_felnehezsuly",
  "4 1 torna talaj",
  "4 1 birkozas kotottfogas_kozepsuly",
  "4 1 birkozas kotottfogas_konnyusuly",
  "5 1 okolvivas pehelysuly",
  "5 1 okolvivas konnyusuly",
  "5 1 uszas 100m_gyors",
  "5 1 atletika diszkoszvetes",
  "5 1 vivas parbajtor_egyeni",
  "5 2 kajak kenu kenu_kettes_1000m",
  "5 2 kerekparozas ketuleses_verseny",
  "5 4 uszas 4 200m_gyorsvalto",
  "5 5 vivas parbajtor_csapat",
  "6 1 birkozas kotottfogas_legsuly",
  "6 1 kajak kenu kajak_egyes_500m",
  "6 1 torna osszetett_egyeni",
  "6 1 kerekparozas repuloverseny",
  "6 1 uszas 400m_gyors",
  "6 1 torna felemaskorlat",
  "6 8 torna osszetett_csapat",
];

/* 1. feladat Készítsen  programkódot  a  következő  feladatok  megoldására,  amelynek  a 
 forráskódját(állományát) helsinki1952 néven mentse el! (ts, js és html állomány)*/

/*2. feladat Olvassa be a helsinkiAdat.js állományban lévő adatokat és tárolja el egy olyan 
adatszerkezetben,  amely  a  további  feladatok  megoldására  alkalmas!  A  fájlban 
legfeljebb 200 sor lehet. */

interface olimpiaAdat {
  helyezes: number;
  sportolokszama: number;
  sportag: string;
  versenyszam: string;

}

function OlimpiaObjektum(elemFeltolto: string[]): olimpiaAdat[] {
  var bentiAdatok: olimpiaAdat[] = [];
  for (var i: number = 0; i < elemFeltolto.length; i++) {
    var daraboltAdatok: any = elemFeltolto[i].split(" ");
    var objektum: olimpiaAdat = {
      helyezes: Number(daraboltAdatok[0]),
      sportolokszama: Number(daraboltAdatok[1]),
      sportag: String(daraboltAdatok[2]),
      versenyszam: String(daraboltAdatok[3]),
    };
    bentiAdatok.push(objektum);
  }
  return bentiAdatok;

}

console.log(OlimpiaObjektum(eredmenyek));

/*3. feladat Határozza meg és írja ki a képernyőre a minta szerint, hogy hány pontszerző helyezést 
értek el a magyar olimpikonok!*/

var magyarAdat: olimpiaAdat[] = OlimpiaObjektum(eredmenyek);

function PontSzerzoHelyezes(adatok: olimpiaAdat[]): number { return adatok.length }

document.write("<br>3.feladat <br>A pontszerző helyezések száma:" + PontSzerzoHelyezes(magyarAdat));

/*4. feladat Készítsen statisztikát a megszerzett érmek számáról, majd összesítse az érmek számát 
a minta szerint! */

function ErmekSzama(adatok: olimpiaAdat[]): [number, number, number, number] {
  var arany: number = 0;
  var ezust: number = 0;
  var bronz: number = 0;
  var osszes: number = 0;

  for (var i: number = 0; i < adatok.length; i++) {
    if (adatok[i].helyezes == 1) {
      arany++;
      osszes++;
    }
    if (adatok[i].helyezes == 2) {
      ezust++;
      osszes++;
    }
    if (adatok[i].helyezes == 3) {
      bronz++;
      osszes++;
    }
  }
  return [arany, ezust, bronz, osszes];
}

var Ermek: [number, number, number, number] = ErmekSzama(magyarAdat);
document.write("<br>4. feladat<br> Arany:" + Ermek[0]);
document.write("<br> Ezüst:" + Ermek[1]);
document.write("<br> Bronz:" + Ermek[2]);
document.write("<br> Összesen:" + Ermek[3]);

/* 5. feladat Az  olimpián  az  országokat  az  elért  eredményeik  alapján  rangsorolják.  Az  1−6. helyezéseket olimpiai pontokra váltják, és ezt összegzik. Határozza meg és írja ki a minta szerint az elért olimpiai pontok összegét az alábbi táblázat segítségével! */

function OlimpiaiPontok(adatok: olimpiaAdat[]): number {
  var OsszPont: number = 0;
  for (var i: number = 0; i < adatok.length; i++) {
    if (adatok[i].helyezes == 1) { OsszPont += 7; }
    else if (adatok[i].helyezes == 2) { OsszPont += 5; }
    else if (adatok[i].helyezes == 3) { OsszPont += 4; }
    else if (adatok[i].helyezes == 4) { OsszPont += 3; }
    else if (adatok[i].helyezes == 5) { OsszPont += 2; }
    else { OsszPont += 1; }

  }
  return OsszPont;
}
document.write("<br> 5.feladat");
document.write("<br> Olimpiai pontok száma:" + OlimpiaiPontok(magyarAdat));

/*6. feladat Az úszás és a torna sportágakban világversenyeken mindig jól szerepeltek a magyar 
sportolók. Határozza meg és írja ki a minta szerint, hogy az 1952-es  nyári  olimpián  
melyik  sportágban  szereztek  több  érmet  a  sportolók!  Ha  az  érmek  száma  egyenlő, 
akkor az „Egyenlő volt az érmek száma” felirat jelenjen meg! */

document.write("<br> 6.feladat");
function TornaUszasErmek(adatok: olimpiaAdat[]) {
  var uszas: number = 0;
  var torna: number = 0;
  for (var i: number = 0; i < adatok.length; i++) {
    if (adatok[i].helyezes < 4 && adatok[i].sportag == "uszas") { uszas++; }
    if (adatok[i].helyezes < 4 && adatok[i].sportag == "torna") { torna++; }
  }

  if (torna > uszas) { document.write("<br> Torna sportágban szereztek több érmet!"); }
  else if (uszas > torna) { document.write("<br> Úszás sportágban szereztek több érmet!") }
  else { document.write("<br> Az érmek száma egyenlő!"); }

}
TornaUszasErmek(magyarAdat);

/* 7. feladat Határozza meg, hogy melyik pontszerző helyezéshez fűződik a legtöbb sportoló! Írja 
ki a minta szerint a helyezést, a sportágat, a versenyszámot és a sportolók számát! 
Feltételezheti, hogy nem alakult ki holtverseny.*/

function LegtobbPontszerzoSportolo(adatok: olimpiaAdat[]): any {
  var MaxSportolo: any = adatok[0];
  for (var i: number = 0; i < adatok.length; i++) {
    if (adatok[i].sportolokszama > MaxSportolo.sportolokszama) { MaxSportolo = adatok[i]; }
  }

  return MaxSportolo;


}

var LegtobbSportolo = LegtobbPontszerzoSportolo(magyarAdat)
document.write("<br>7.feladat<br>Helyezes:" + LegtobbSportolo.helyezes);
document.write("<br>Sportág:" + LegtobbSportolo.sportag);
document.write("<br>Versenyszam:" + LegtobbSportolo.versenyszam);
document.write("<br>Sportolók száma:" + LegtobbSportolo.sportolokszama);