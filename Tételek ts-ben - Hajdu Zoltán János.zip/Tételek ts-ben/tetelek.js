var szamokTombje = [3, 13, 21, 33, 42, 1, 92, 7, 66];
function MaxErtekFuggveny(vizsgaltTomb) {
    var MaxErtek = vizsgaltTomb[0];
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] > MaxErtek)
            MaxErtek = vizsgaltTomb[i];
    }
    return MaxErtek;
}
console.log(MaxErtekFuggveny(szamokTombje));
function MinErtekFuggveny(vizsgaltTomb) {
    var MinErtek = vizsgaltTomb[0];
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] < MinErtek)
            MinErtek = vizsgaltTomb[i];
    }
    return MinErtek;
}
console.log(MinErtekFuggveny(szamokTombje));
function MaxIndexFuggveny(vizsgaltTomb) {
    var MaxIndex = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] > vizsgaltTomb[MaxIndex])
            MaxIndex = i;
    }
    return MaxIndex;
}
console.log(MaxIndexFuggveny(szamokTombje));
function MinIndexFuggveny(vizsgaltTomb) {
    var MinIndex = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] < vizsgaltTomb[MinIndex])
            MinIndex = i;
    }
    return MinIndex;
}
console.log(MinIndexFuggveny(szamokTombje));
function KivalogatasTeteleFuggveny(vizsgaltTomb) {
    var eredmenyek = [];
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % 2 == 0) {
            eredmenyek.push(vizsgaltTomb[i]);
        }
    }
    return eredmenyek;
}
console.log(KivalogatasTeteleFuggveny(szamokTombje));
function MegSzamlalasTeteleFuggveny(vizsgaltTomb) {
    var darab = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % 2 == 0) {
            darab++;
        }
    }
    return darab;
}
console.log(MegSzamlalasTeteleFuggveny(szamokTombje));
function AtlagSzamitasFuggveny(vizsgaltTomb) {
    var osszeg = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        osszeg += vizsgaltTomb[i];
    }
    return Math.round(osszeg / vizsgaltTomb.length);
}
console.log(AtlagSzamitasFuggveny(szamokTombje));
function OsszegzesTeteleFuggveny(vizsgaltTomb) {
    var osszeg = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        osszeg += vizsgaltTomb[i];
    }
    return osszeg;
}
console.log(OsszegzesTeteleFuggveny(szamokTombje));
function MegSzamlalasTeteleParosIndexAlapjanFuggveny(vizsgaltTomb) {
    var osszeg = 0;
    for (var i = 1; i < vizsgaltTomb.length; i++) {
        if (i % 2 == 0) {
            osszeg++;
        }
    }
    return osszeg;
}
console.log(MegSzamlalasTeteleParosIndexAlapjanFuggveny(szamokTombje));
