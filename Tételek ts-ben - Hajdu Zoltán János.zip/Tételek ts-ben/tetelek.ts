var szamokTombje: number[] = [3, 13, 21, 33, 42, 1, 92, 7, 66];

function MaxErtekFuggveny(vizsgaltTomb: number[]): number {
    let MaxErtek: number = vizsgaltTomb[0];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] > MaxErtek)
            MaxErtek = vizsgaltTomb[i];
    }

    return MaxErtek;
}

console.log(MaxErtekFuggveny(szamokTombje));

function MinErtekFuggveny(vizsgaltTomb: number[]): number {
    let MinErtek: number = vizsgaltTomb[0];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] < MinErtek)
            MinErtek = vizsgaltTomb[i];
    }

    return MinErtek;
}

console.log(MinErtekFuggveny(szamokTombje));

function MaxIndexFuggveny(vizsgaltTomb: number[]): number {
    let MaxIndex: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] > vizsgaltTomb[MaxIndex])
            MaxIndex = i;
    }

    return MaxIndex;
}

console.log(MaxIndexFuggveny(szamokTombje));

function MinIndexFuggveny(vizsgaltTomb: number[]): number {
    let MinIndex: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] < vizsgaltTomb[MinIndex])
            MinIndex = i;
    }

    return MinIndex;
}

console.log(MinIndexFuggveny(szamokTombje));

function KivalogatasTeteleFuggveny(vizsgaltTomb: number[]): number[] {
    let eredmenyek: number[] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % 2 == 0) { eredmenyek.push(vizsgaltTomb[i]); }
    }
    return eredmenyek;
}

console.log(KivalogatasTeteleFuggveny(szamokTombje));

function MegSzamlalasTeteleFuggveny(vizsgaltTomb: number[]): number {
    let darab: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % 2 == 0) { darab++; }
    }
    return darab;
}

console.log(MegSzamlalasTeteleFuggveny(szamokTombje));


function AtlagSzamitasFuggveny(vizsgaltTomb: number[]): number {
    let osszeg: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) { osszeg += vizsgaltTomb[i]; }

    return Math.round(osszeg / vizsgaltTomb.length);
}

console.log(AtlagSzamitasFuggveny(szamokTombje));



function OsszegzesTeteleFuggveny(vizsgaltTomb: number[]): number {
    let osszeg: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) { osszeg += vizsgaltTomb[i]; }

    return osszeg;
}

console.log(OsszegzesTeteleFuggveny(szamokTombje));






function MegSzamlalasTeteleParosIndexAlapjanFuggveny(vizsgaltTomb: number[]): number {
    let osszeg: number = 0;
    for (let i: number = 1; i < vizsgaltTomb.length; i++) {
        if (i % 2 == 0) { osszeg++; }
    }
    return osszeg;
}

console.log(MegSzamlalasTeteleParosIndexAlapjanFuggveny(szamokTombje));

