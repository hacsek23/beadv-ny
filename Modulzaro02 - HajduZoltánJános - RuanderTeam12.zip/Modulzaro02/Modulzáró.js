/*1. feladat (3 pont) 
Készíts egy függvényt, ami egy paraméterként megkapott oldal méretből, a hozzá tartozó kocka 
felszínének méretét visszaadja. 
Függvény neve: KockaFelszin() Paraméter(ek): a (az oldal mérete) Visszatérési értéke: szám érték 
Tesztesetek: KockaFelszin(2) eredménye: 24 
KockaFelszin(3) eredménye: 54 
KockaFelszin(5) eredménye: 15*/


function KockaFelszin(aOldal)
{
let felszin=6*(aOldal*aOldal);

return felszin;
}

document.write("Az első kocka felszíne:"+KockaFelszin(2));
document.write("<br>A második kocka felszíne:"+KockaFelszin(3));
document.write("<br>A harmadik kocka felszíne:"+KockaFelszin(5));

/*2. feladat (3 pont) 
Készíts egy függvényt, ami egy paraméterként megkapott oldal méretből, a hozzá tartozó kocka 
térfogatának méretét visszaadja. 
Függvény neve: KockaTerfogat() Paraméter(ek): a (az oldal mérete) Visszatérési értéke: szám érték 
Tesztesetek: KockaTerfogat(2) eredménye: 8 
KockaTerfogat(3) eredménye: 27 
KockaTerfogat(5) eredménye: 125*/

function KockaTerfogat(aOldal)
{
let terfogat=aOldal*aOldal*aOldal;

return terfogat;
}

document.write("Az első kocka térfogata:"+KockaTerfogat(2));
document.write("<br>A második kocka térfogata:"+KockaTerfogat(3));
document.write("<br>A harmadik kocka térfogata:"+KockaTerfogat(5));


/*3. feladat (6 pont) 
Készíts egy függvényt, ami egy paraméterként megkapott ph értékből megmondja annak állapotát 
(savas, lúgos, vagy épp semleges) 
7 esetén az érték semleges, alatta savas, felette pedig lúgos állapotú 
Függvény neve: PhErtek() Paraméter(ek): vizsgaltErtek Visszatérési értéke: szöveg érték*/

function PhErtek(vizsgaltErtek) {
    if (vizsgaltErtek>0 && vizsgaltErtek < 7) {
      return "savas";
    } else if (14> vizsgaltErtek && vizsgaltErtek> 7) {
      return "lugos";
    } else if (vizsgaltErtek==7){
      return "semleges";
    }
  
    else
    {return "hibás érték"}
  }
  
  document.write(PhErtek(9));
  document.write("<br>"+PhErtek(5.5));
  document.write("<br>"+PhErtek(7));
/*4. feladat (8 pont) 
Készíts egy függvényt, ami egy paraméterként megkapott N értékből kiszámolja az addig lévő 
természetes számok összegét. Pl.: 3 esetén, 1+2+3=6-tal 
Függvény neve: ElsoNSzamOsszege() Paraméter(ek): szamokMennyisege  Visszatérési értéke: szám érték 
Tesztesetek: 
ElsoNSzamOsszege(3) eredménye: 6 
ElsoNSzamOsszege(10) eredménye: 55 
ElsoNSzamOsszege(21) eredménye: 231*/

function ElsoNSzamOsszege(szamok)
{
let osszeg=0;
for(let i=1; i<=szamok; i++)
{osszeg+=i;}

return osszeg;

}

document.write(ElsoNSzamOsszege(3));
document.write("<br>"+ElsoNSzamOsszege(10));
document.write("<br>"+ElsoNSzamOsszege(21));


/*5. feladat (10 pont) 
Készíts egy függvényt, ami egy paraméterként megkapott tömbből kiválasztja az abban szereplő 
legnagyobb páros számot! 
Függvény neve: MaxParos() Paraméter(ek): vizsgaltTomb Visszatérési értéke: szám érték 
Tesztesetek: 
MaxParos ([12,3,7,19,21]) eredménye: 12 
MaxParos ([28,14,2,42,69]) eredménye: 42 
MaxParos ([32,21,54,33,21]) eredménye: 54*/

function MaxParos(vizsgaltTomb)

{
let maxParos=vizsgaltTomb[0];
for(let i=0; i<vizsgaltTomb.length; i++)
if(vizsgaltTomb[i]>maxParos && vizsgaltTomb[i]%2==0)
{maxParos=vizsgaltTomb[i];}

return maxParos;
}

document.write("A legnagyobb páros szám a tömbben:"+MaxParos([12,3,7,19,21]));
document.write("<br>A legnagyobb páros szám a tömbben:"+MaxParos([28,14,2,42,69]));
document.write("<br>A legnagyobb páros szám a tömbben:"+MaxParos([32,21,54,33,21]));

/*6. feladat (11 pont) 
Készíts egy függvényt, ami egy paraméterként megkapott szövegről megmondja, hány magánhangzót 
tartalmaz. 
Függvény neve: MaganHangzokSzama() Paraméter(ek): vizsgaltSzoveg Visszatérési értéke: szám érték 
  
Junior Frontend feladatsor – JavaScript Modulrész 
Tesztesetek: 
MaganHangzokSzama("Szeretem a programozás") eredménye: 8 
MaganHangzokSzama("Géza kék az ég") eredménye: 5 
MaganHangzokSzama("Répa, retek, mogyoró") eredménye: 7 */

function MaganHangzokSzama(vizsgaltSzoveg)
{
let maganhangzok=['a','á','e','é','i','í','o','ó','ö','ő','u','ú','ü','ű','A','Á','E','É','I','Í','O','Ó','Ö','Ő','U','Ú','Ü','Ű'];
let db=0;
for(let i=0; i<vizsgaltSzoveg.length; i++)
{for(let j=0; j<maganhangzok.length; j++)
{if(vizsgaltSzoveg[i].includes(maganhangzok[j]))
{db++;
}
}

}
return db;
}

document.write(MaganHangzokSzama("Szeretem a programozás"));
document.write("<br>"+MaganHangzokSzama("Géza, kék az ég"));
document.write("<br>"+MaganHangzokSzama("Répa, retek, mogyoró"));

/*7. feladat (9 pont) 
/ Készíts egy függvényt, ami egy paraméterként megkapott szöveget visszafelé készíti el. 
Függvény neve: SzovegVisszafele() Paraméter(ek): szoveg Visszatérési értéke: szöveg érték 
Tesztesetek: 
SzovegVisszafele("Szeretem a programozás")eredménye: „sázomargorp a meterezS” 
SzovegVisszafele("Géza kék az ég")eredménye: „gé za kék azéG” 
SzovegVisszafele("Répa, retek, mogyoró")eredménye: „óroygom ,keter ,apéR*/

function SzovegVisszafele(szoveg) {
    return szoveg.split("").reverse().join("");
  }
  document.write("<br>"+SzovegVisszafele("Szeretem a programozás"));
  document.write("<br>"+SzovegVisszafele("Géza kék az ég"));
  document.write("<br>"+SzovegVisszafele("Répa, retek, mogyoró"));

/*8. feladat (10 pont) 
A feladatsor mellé megadott objektum segítségével határozza meg mennyi az objektumban található 
dolgozók átlagéletkora. (Az eredményt egész számra kerekítve adja meg) 
Függvény neve: CegAtlagEletkor() Paraméter(ek): vizsgaltObjektumTomb Visszatérési értéke: szám érték 
Teszteset: 
CegAtlagEletkor(Dolgozok)eredménye: 34 */


const Dolgozok = [{
    nev: "Koaxk Ábel",
    kor: 23,
    fizetes: 400000,
    beosztas: "Rendszergazda"
},
{
    nev: "Zsíros B. Ödön",
    kor: 45,
    fizetes: 1200000,
    beosztas: "Ügyvezető Igazgató"
},
{
    nev: "Meg Győző",
    kor: 32,
    fizetes: 600000,
    beosztas: "Marketing Manager"
},
{
    nev: "Békés Csaba",
    kor: 63,
    fizetes: 180000,
    beosztas: "Takarító"
},
{
    nev: "Pofá Zoltán",
    kor: 25,
    fizetes: 300000,
    beosztas: "Biztonsági Őr"
},
{
    nev: "Fejet Lenke",
    kor: 22,
    fizetes: 220000,
    beosztas: "Irodai Titkár"
},
{
    nev: "Vak Cina",
    kor: 30,
    fizetes: 500000,
    beosztas: "Üzem Orvos"
}
];


function CegAtlagEletkor(vizsgaltObjektumTomb)
{
let atlagEletkor=0;
for(let i=0; i<vizsgaltObjektumTomb.length; i++)
{
atlagEletkor+=vizsgaltObjektumTomb[i].kor
}
return Math.round(atlagEletkor/vizsgaltObjektumTomb.length);
}

document.write("A dolgozók átlagéletkora:"+CegAtlagEletkor(Dolgozok)+"év");