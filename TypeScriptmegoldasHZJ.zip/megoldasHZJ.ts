/* 1. feladat – Diák infó [DiakInfo]
Készítsen egy függvényt három paraméterrel [nev:szoveg], [csoport:szam] és [típus:bool]
A név változót egy az egyben adja vissza a stringben, a csoport változót fűzze hozzű kiegészítve írassa 
ki írja elé a „Team” kifejezést, a bool változó [true] esetén a „Junior Frontend” [false] esetén a 
„Webprogramozó” szöveg jelenjen meg a függvény által.
Kipróbálásra: DiakInfo(„Minta Márton”, 8, true);
Visszatérési érték[string]: Minta Márton [Team08] – Junior Frontend
(Megjegyzés, a szavak közötti távolság egy szóköz!) */

function DiakInfo (nev:string, csoport:number, tipus:boolean):any
{
var csapat:string=" Team0";

let szoveg:string=nev+=csapat+=csoport;

if(tipus)
{szoveg+=" Junior Frontend";}

else
{szoveg+=" Webprogramozó";}

return szoveg;

} 

console.log(DiakInfo("Minta Márton", 8, true));

/*2. feladat – Magatartás-Szorgalom [SzovegesErtekeles]
Készíts egy függvényt, ami bemeneti paraméternek vár egy számot [jegy], ami visszatért két értékkel, 
az adott bemeneti paraméter szöveges értékelésével, 2 PARAMÉTERREL! (Használj Tuple-t)
Segítség a szöveges visszatérési értékekhez
Jegy Szorgalom Magatartás
5 Példás Példás
4 Jó Jó
3 Változó Változó
2 Hanyag Rossz
Kipróbálásra: SzovegesErtekeles(2);
Visszatérési érték[string] tuple: [Hanyag,Rossz]*/

function SzovegesErtekelesFuggveny(jegy:number):[string, string]
{
if(jegy===5)
{return ["Példás", "Példás"];}

if(jegy===4)
{return ["Jó", "Jó"];}

if(jegy===3)
{return ["Változó", "Változó"];}

if(jegy===2)
{return ["Hanyag", "Rossz"];}

}

var Szoveg:[string,string]=SzovegesErtekelesFuggveny(2);
console.log(Szoveg[0]);
console.log(Szoveg[1]);

/* 3. feladat – Hárommal oszható számok listája [HarommalOszthatokSzama]
Készíts egy tömb bemeneti paraméterrel rendelkező függvényt, ami visszaadja a tömbben lévő 
hárommal osztható számok mennyiségét.
Kipróbálásra: HarommalOszthatokSzama([10, 23, 12, 24, 31, 33, 42, 20 ]);
Visszatérési érték[number]: 4  */

function HarommalOszthatokSzama(tomb:number[]):number {
    var db:number=0;
    for(let i=0; i<tomb.length; i++)
    {if(tomb[i]%3==0)
    {db++}
    }
    return db;

}

console.log(HarommalOszthatokSzama([10, 23, 12, 24, 31, 33, 42, 20 ]));

/*4. feladat – Nyerőszám sorsoló [Nyeroszamok]
Készítsen egy függvényt háromparaméterrel [mennyiseg], [alsoHatar] és [felsoHatar], oldja meg 
hogy kigeneráljon adott mennyiségű számot az alsó és a felső határon belül, és azokban, NE LEGYEN 
ISMÉTLŐDÉS!
Kipróbálásra: Nyeroszamok(5,1,90);
Visszatérési érték[Array]: adott intervallumban lévő számok ismétlés nélkül.*/

function NyeroSzamok(mennyiseg:number, alsoHatar:number, felsoHatar:number):number[]
{
var generaltSzamok:number[]=[];
for(let i=0; i<5; i++)
{generaltSzamok.push(Math.round(Math.random()*felsoHatar-alsoHatar)+1);}

return generaltSzamok;

}

console.log(NyeroSzamok(5,1,90));