var csapatAdat = [
    "Anglia;4;0;1662",
    "Argentína;10;0;1614",
    "Belgium;1;0;1752",
    "Brazília;3;-1;1719",
    "Chile;17;-3;1576",
    "Dánia;14;-1;1584",
    "Franciaország;2;1;1725",
    "Hollandia;13;3;1586",
    "Horvátország;8;-1;1625",
    "Kolumbia;9;-1;1622",
    "Mexikó;12;0;1603",
    "Németország;16;-1;1580",
    "Olaszország;15;1;1583",
    "Peru;19;0;1551",
    "Portugália;5;1;1643",
    "Spanyolország;7;2;1631",
    "Svájc;11;0;1604",
    "Svédország;18;0;1560",
    "Szenegál;20;0;1546",
    "Uruguay;6;-1;1639"
];
function ObjektumFeltoltoke(feltoltendoElem) {
    var beolvasottAdatok = [];
    for (var i = 0; i < feltoltendoElem.length; i++) {
        var daraboltAdatSor = feltoltendoElem[i].split(';');
        var objektum = {
            csapatnev: String(daraboltAdatSor[0]),
            helyezes: Number(daraboltAdatSor[1]),
            valtozas: Number(daraboltAdatSor[2]),
            pont: Number(daraboltAdatSor[3]),
        };
        beolvasottAdatok.push(objektum);
    }
    return beolvasottAdatok;
}
var fifaOsszes = ObjektumFeltoltoke(csapatAdat);
function Adatkiiroka(adatok) {
    for (var i = 0; i < adatok.length; i++) {
        console.log(adatok[i].csapatnev + ":" + adatok[i].helyezes + ":" + adatok[i].valtozas + ":" + adatok[i].pont);
    }
}
Adatkiiroka(fifaOsszes);
// 1) Adja meg aktuálisan hány csapat szerepel a ranglistán 
function CsapatokSzamai(adatok) {
    var csapatokSzama = 0;
    for (var i = 0; i < adatok.length; i++) {
        csapatokSzama++;
    }
    return csapatokSzama;
}
console.log("A listán szereplő csapatok száma:" + CsapatokSzamai(fifaOsszes));
// 2) Írja ki mennyi a résztvevő csapatok átlagpontszáma
function AtlagPontszamok(adatok) {
    var pont = 0;
    for (var i = 0; i < adatok.length; i++) {
        pont += adatok[i].pont;
    }
    return Math.round(pont / adatok.length);
}
console.log("A listán szereplő csapatok átlagpontszáma:" + AtlagPontszamok(fifaOsszes));
// 3) Listázza ki azokat a csapatokat, akik az átlagnál több pontot értek el!
var atlag = AtlagPontszamok(fifaOsszes);
function AtlagFelettiek(adatok) {
    for (var i = 0; i < adatok.length; i++) {
        if (adatok[i].pont > atlag) {
            console.log(adatok[i].csapatnev);
        }
    }
}
AtlagFelettiek(fifaOsszes);
/* 4) Írja ki a legtöbbet javító csapat adatait: Helyezés, CsapatNeve, Pontszáma
 
pl.:
    Helyezés: 13
    Csapat: Hollandia
    Pontszáma: 1586*/
function legTobbetJavitoCsapat(adatok) {
    var legtobbetJavito = 0;
    for (var i = 0; i < adatok.length; i++) {
        if (adatok[i].valtozas > adatok[legtobbetJavito].valtozas) {
            legtobbetJavito = i;
        }
    }
    console.log(adatok[legtobbetJavito].csapatnev);
    console.log(adatok[legtobbetJavito].helyezes);
    console.log(adatok[legtobbetJavito].pont);
}
legTobbetJavitoCsapat(fifaOsszes);
/* 5) Határozza meg a adatok között megtalálható-e Magyarország csapata!
 
 pl.:
     "A csapatok között nincs Magyarország"
     illetve
     "A csapatok között szerepel Magyarország"*/
function VanEMagyarorszag(adatok) {
    var megfelelE = false;
    for (var i = 0; i < adatok.length; i++) {
        if (adatok[i].csapatnev == "Magyarország") {
            megfelelE = true;
        }
    }
    if (megfelelE == true) {
        console.log("A csapatok között szerepel Magyarország!");
    }
    else {
        console.log("A csapatok között nem szerepel Magyarország!");
    }
}
VanEMagyarorszag(fifaOsszes);
/*6) Készítsen statisztikát a helyezések változása (Valtozas) alapján csoportosítva a
csapatok számáról a minta szerint! Csak azok a helyezésváltozások jelenjenek meg a
képenyőn, amelyek esetében a csapatok száma több mint egy volt! A megjelenő
csoportok sorrendje tetszőleges.
 
    pl.:
    0 helyet változott: 8 csapat
    -1 helyet változott: 6 csapat
    1 helyet változott: 3 csapat*/
function TescosStatisztika(adatok) {
    var minuszegy = 0;
    var nulla = 0;
    var egy = 0;
    for (var i = 0; i < adatok.length; i++) {
        if (adatok[i].valtozas == -1) {
            minuszegy++;
        }
        else if (adatok[i].valtozas == 1) {
            egy++;
        }
        else if (adatok[i].valtozas == 0) {
            nulla++;
        }
        else { }
    }
    console.log("7. feladat Statisztika(TESCO-s)");
    console.log("\t0 helyet változtatott: " + nulla + " csapat");
    console.log("\t-1 helyet változtatott: " + minuszegy + " csapat");
    console.log("\t1 helyet változtatott: " + egy + " csapat");
}
TescosStatisztika(fifaOsszes);
